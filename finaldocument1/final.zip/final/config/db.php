<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=final',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',

];
